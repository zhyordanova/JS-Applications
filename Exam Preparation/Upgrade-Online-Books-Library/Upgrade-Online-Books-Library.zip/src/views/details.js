import { html } from '../lib.js';
import { deleteBookById, getBookById, getLikesByBookId, getMyLikedBooksById, likeBook } from '../api/data.js';
import { getUserData } from '../util.js';

const detailsTemplate = (book, isOwner, onDelete, likes, showLikeButton, onLike) => html`
<section id="details-page" class="details">
    <div class="book-information">
        <h3>${book.title}</h3>
        <p class="type">Type: ${book.type}</p>
        <p class="img"><img src=${book.imageUrl}></p>
        <div class="actions">
            ${bookControlTemplate(book, isOwner, onDelete)}

            ${likeControlTemplate(showLikeButton, onLike)}

            <div class="likes">
                <img class="hearts" src="/images/heart.png">
                <span id="total-likes">Likes: ${likes}</span>
            </div>
        </div>
    </div>
    <div class="book-description">
        <h3>Description:</h3>
        <p>${book.description}</p>
    </div>
</section>`;

const bookControlTemplate = (book, isOwner, onDelete) => {
    if (isOwner) {
        return html`
        <a class="button" href="/edit/${book._id}">Edit</a>
        <a @click=${onDelete} class="button" href="javascript:void(0)">Delete</a>`
    }
};

const likeControlTemplate = (showLikeButton, onLike) => {
    if (showLikeButton) {
        return html`<a @click=${onLike} class="button" href="javascript:void(0)">Like</a>`
    } else {
        return null;
    }
}

export async function detailsPage(ctx) {
    const bookId = ctx.params.id
    const userData = getUserData();

    const [book, likes, hasLiked] = await Promise.all([
        getBookById(bookId),
        getLikesByBookId(bookId),
        userData ? getMyLikedBooksById(bookId, userData.id) : 0
    ])

    const isOwner = userData && book._ownerId == userData.id;
    const showLikeButton = userData != null && isOwner == false && hasLiked == false

    ctx.render(detailsTemplate(book, isOwner, onDelete, likes, showLikeButton, onLike));

    async function onDelete() {
        const confirmed = confirm(`Are you sure you want to delete ${book.title}`);

        if (confirmed) {
            await deleteBookById(bookId);
            ctx.page.redirect('/')
        }
    }

    async function onLike() {
        await likeBook(bookId);
        ctx.page.redirect('/details/' + bookId);
    }
}